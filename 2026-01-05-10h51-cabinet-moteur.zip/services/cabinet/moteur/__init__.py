# services/cabinet/moteur/__init__.py

