import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSession } from "../context/SessionContext";
import {
  listerJoueursTable,
  joueurPret,
  lancerPartie
} from "../api/lobbyApi";
import type { ReponseListeJoueursTable } from "../types/lobby";
import Button from "../components/shared/Button";
import Loading from "../components/shared/Loading";
import { useSituationPolling } from "../hooks/useSituationPolling";

const TableWaitingPage: React.FC = () => {
  const { tableId } = useParams<{ tableId: string }>();
  const { joueur } = useSession();
  const navigate = useNavigate();
  // On poll ui-etat-joueur pour savoir si on est passé en mode "partie"
  const { situation, marqueurs, ancrage } =
    useSituationPolling(joueur?.id_joueur, { intervalMs: 2000 });


  const [etatTable, setEtatTable] = useState<ReponseListeJoueursTable | null>(null);
  const [loading, setLoading] = useState(true);
  const [erreur, setErreur] = useState<string | null>(null);
  const [lancementEnCours, setLancementEnCours] = useState(false);

  useEffect(() => {
    if (!joueur) {
      navigate("/auth");
      return;
    }
    if (!tableId) return;

    async function charger() {
      try {
        const data = await listerJoueursTable(tableId);
        setEtatTable(data);
      } catch (err) {
        setErreur((err as Error).message);
      } finally {
        setLoading(false);
      }
    }

    charger();
    const interval = setInterval(charger, 3000);
    return () => clearInterval(interval);
  }, [joueur, tableId, navigate]);

  // Quand ui-etat-joueur indique que la partie est lancée pour ce joueur,
  // on bascule automatiquement vers la page de jeu.
  useEffect(() => {
    if (!situation) return;

    // 1) Si l’ancrage indique déjà une partie, on redirige
    if (ancrage?.type === "partie" && ancrage.partie_id) {
      navigate(`/parties/${ancrage.partie_id}`);
      return;
    }

    // 2) Sinon on se base sur les marqueurs "en_partie"
    if (marqueurs.en_partie && ancrage?.partie_id) {
      navigate(`/parties/${ancrage.partie_id}`);
      return;
    }

    // 3) ui-état demande un retour au lobby (fin de partie ou dissolution)
    if (marqueurs.retour_lobby) {
      navigate("/lobby");
      return;
    }
  }, [situation, marqueurs, ancrage, navigate]);


  if (!joueur || !tableId) return null;

  if (loading || !etatTable) {
    return <Loading message="Chargement de la table…" />;
  }

  const moi = etatTable.joueurs.find((j) => j.id_joueur === joueur.id_joueur);
  const estHote = moi?.role === "hote";
  const tousPrets =
    etatTable.joueurs.length > 0 &&
    etatTable.joueurs.every((j) => j.pret === true);

  async function handlePret() {
    try {
      await joueurPret({ id_table: tableId, id_joueur: joueur.id_joueur });
      const data = await listerJoueursTable(tableId);
      setEtatTable(data);
    } catch (err) {
      setErreur((err as Error).message);
    }
  }

  async function handleLancer() {
    if (!estHote) return;
    setLancementEnCours(true);
    try {
      const resp = await lancerPartie({
        id_table: tableId,
        id_hote: joueur.id_joueur
      });
      navigate(`/parties/${resp.id_partie}`);
    } catch (err) {
      setErreur((err as Error).message);
      setLancementEnCours(false);
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Table {etatTable.id_table}</h2>
      <p className="text-sm opacity-80">
        En attente des joueurs. Quand tout le monde est prêt, l’hôte peut lancer
        la partie.
      </p>

      <div className="border border-slate-800 rounded p-3 space-y-2">
        <h3 className="font-semibold text-sm">Joueurs</h3>
        <ul className="space-y-1 text-sm">
          {etatTable.joueurs.map((j) => (
            <li
              key={j.id_joueur}
              className="flex items-center justify-between border border-slate-800 rounded px-2 py-1"
            >
              <div>
                <div className="font-medium">
                  {j.alias || j.nom} ({j.role})
                  {j.id_joueur === joueur.id_joueur && " · vous"}
                </div>
                <div className="text-xs opacity-70">{j.courriel}</div>
              </div>
              <span className="text-xs">
                {j.pret ? "✅ prêt" : "⏳ en attente"}
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="flex gap-3">
        <Button onClick={handlePret} disabled={moi?.pret}>
          {moi?.pret ? "Vous êtes prêt" : "Je suis prêt"}
        </Button>

        {estHote && (
          <Button
            variant="secondary"
            onClick={handleLancer}
            disabled={!tousPrets || lancementEnCours}
          >
            {lancementEnCours ? "Lancement…" : "Lancer la partie"}
          </Button>
        )}
      </div>

      {erreur && <p className="text-sm text-red-400">{erreur}</p>}
    </div>
  );
};

export default TableWaitingPage;
