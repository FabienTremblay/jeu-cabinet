// src/types/common.ts
export interface ApiError {
  message: string;
  status?: number;
}

