from __future__ import annotations

from typing import Dict, Iterable, Optional

from .domaine import Joueur, Table, StatutTable


class JoueurRepository:
    """Dépôt simple en mémoire pour les joueurs."""

    def __init__(self) -> None:
        self._par_id: Dict[str, Joueur] = {}
        self._par_courriel: Dict[str, Joueur] = {}

    def ajouter(self, joueur: Joueur) -> None:
        """Ajoute ou remplace un joueur dans le dépôt."""
        self._par_id[joueur.id_joueur] = joueur
        self._par_courriel[str(joueur.courriel)] = joueur

    def trouver_par_id(self, id_joueur: str) -> Optional[Joueur]:
        """Retrouve un joueur par son identifiant."""
        return self._par_id.get(id_joueur)

    def trouver_par_courriel(self, courriel: str) -> Optional[Joueur]:
        """Retrouve un joueur par son courriel."""
        return self._par_courriel.get(courriel)

    def lister(self) -> Iterable[Joueur]:
        """Itère sur tous les joueurs connus."""
        return self._par_id.values()

    # ---- génération d'identifiants --------------------------------------

    def prochain_id(self) -> str:
        """
        Génère un identifiant de joueur simple.
        On reste en mémoire, donc un compteur suffit.
        """
        return f"J{len(self._par_id) + 1:06d}"


class TableRepository:
    """Dépôt en mémoire pour les tables du lobby."""

    def __init__(self) -> None:
        self._par_id: Dict[str, Table] = {}
        self._compteur_parties: int = 0

    def ajouter(self, table: Table) -> None:
        """Ajoute ou remplace une table dans le dépôt."""
        self._par_id[table.id_table] = table

    def trouver_par_id(self, id_table: str) -> Optional[Table]:
        """Retrouve une table par son identifiant."""
        return self._par_id.get(id_table)

    def lister(self, statut: StatutTable | None = None) -> Iterable[Table]:
        """Itère sur les tables, avec filtre optionnel sur le statut."""
        for t in self._par_id.values():
            if statut is None or t.statut == statut:
                yield t

    def tous_les_joueurs_assis(self) -> set[str]:
        """Retourne l'ensemble des id_joueur qui occupent un siège à une table."""
        ids: set[str] = set()
        for table in self._par_id.values():
            ids.update(table.joueurs_assis)
        return ids
    # ---- méthodes utilisées par le service ----

    def trouver_table_active_du_joueur(self, id_joueur: str) -> Optional[Table]:
        """
        Retourne la première table 'active' où le joueur est impliqué
        (hôte ou assis).
        Active = ouverte / en_preparation / en_cours.
        """
        statuts_actifs: tuple[StatutTable, ...] = (
            StatutTable.OUVERTE,
            StatutTable.EN_PREPARATION,
            StatutTable.EN_COURS,
        )
        for table in self._par_id.values():
            if table.statut not in statuts_actifs:
                continue
            if table.id_hote == id_joueur or id_joueur in table.joueurs_assis:
                return table
        return None

    def trouver_par_id_partie(self, id_partie: str) -> Optional[Table]:
        """
        Retrouve une table à partir de l'identifiant de partie associé.
        Utile pour rattraper un joueur qui revient avec un id_partie.
        """
        for table in self._par_id.values():
            if table.id_partie == id_partie:
                return table
        return None

    def joueur_est_deja_installe(self, id_joueur: str) -> bool:
        """
        Indique si le joueur est déjà à une table active.
        Utile pour interdire qu'un même joueur participe à plusieurs tables.
        """
        return self.trouver_table_active_du_joueur(id_joueur) is not None

    def marquer_partie_lancee(self, id_table: str, id_partie: str) -> Table:
        """
        Associe une partie à la table et la marque EN_COURS.
        Retourne la table mise à jour.
        """
        table = self.trouver_par_id(id_table)
        if table is None:
            raise ValueError("table_introuvable")

        table.id_partie = id_partie
        table.statut = StatutTable.EN_COURS
        return table

    # ---- génération d'identifiants --------------------------------------

    def prochain_id(self) -> str:
        """
        Génère un identifiant de table.
        """
        return f"T{len(self._par_id) + 1:06d}"

    def prochain_id_partie(self) -> str:
        """
        Génère un identifiant de partie.
        On s'appuie sur un compteur simple interne au dépôt.
        """
        self._compteur_parties += 1
        return f"P{self._compteur_parties:06d}"

    # ------------------------------------------------------------------
    # gestion de la fin de partie / dissolution
    # ------------------------------------------------------------------

    def terminer_table(self, id_table: str) -> Table:
        """
        Marque la table comme terminée côté lobby.

        On délègue la logique métier à Table.terminer_partie().
        Le simple fait que la table passe au statut TERMINEE suffit
        pour que les méthodes qui filtrent sur les statuts « actifs »
        (ouverte, en préparation, en cours) ne la considèrent plus.
        """
        table = self.trouver_par_id(id_table)
        if table is None:
            raise ValueError(f"table_introuvable: {id_table}")

        table.terminer_partie()
        return table

    def dissoudre_table(self, id_table: str) -> Table:
        """
        Dissout complètement la table après la fin de la partie.

        - passe la table au statut TERMINEE;
        - vide les joueurs assis et prêts.

        On conserve néanmoins la table dans le dépôt (pas de delete),
        ce qui évite d'avoir des références orphelines vers son id.
        """
        table = self.trouver_par_id(id_table)
        if table is None:
            raise ValueError(f"table_introuvable: {id_table}")

        table.terminer_partie()
        table.vider_joueurs()
        return table


