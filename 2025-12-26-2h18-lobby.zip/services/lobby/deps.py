# services/lobby/deps.py
from functools import lru_cache
import logging

from .repositories import JoueurRepository, TableRepository
from .kafka_producteur import (
    ProducteurEvenements,
    ProducteurEvenementsLog,
    ProducteurEvenementsKafka,
)
from .settings import settings

logger = logging.getLogger(__name__)

# Instances uniques, partagées
_joueur_repo = JoueurRepository()
_table_repo = TableRepository()


@lru_cache
def get_joueur_repository() -> JoueurRepository:
    return _joueur_repo


@lru_cache
def get_table_repository() -> TableRepository:
    return _table_repo


@lru_cache
def get_producteur_evenements() -> ProducteurEvenements:
    """
    Retourne un producteur Kafka réel si possible, sinon un producteur de log.

    - si settings possède un flag kafka_actif et qu'il est False → on force le LOG
    - sinon on tente ProducteurEvenementsKafka, avec fallback LOG en cas d'erreur
    """
    kafka_actif = getattr(settings, "kafka_actif", True)

    if not kafka_actif:
        logger.warning("Kafka désactivé par configuration, utilisation de ProducteurEvenementsLog")
        return ProducteurEvenementsLog()

    try:
        prod = ProducteurEvenementsKafka()
        logger.info("ProducteurEvenementsKafka initialisé avec succès")
        return prod
    except Exception:
        logger.exception(
            "Impossible d'initialiser ProducteurEvenementsKafka, "
            "fallback vers ProducteurEvenementsLog"
        )
        return ProducteurEvenementsLog()


def get_service_lobby():
    from .services_lobby import ServiceLobby

    return ServiceLobby(
        settings=settings,
        joueurs=get_joueur_repository(),
        tables=get_table_repository(),
        producteur=get_producteur_evenements(),
    )

